<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Pagina principal</title>
  </head>
  <body>
    <form action="insertar.php" method="post">
      Nombre: <br>
      <input type="text" name="nombre"><br>
      Ciudad: <br>
      <input type="text" name="ciudad"><br>
      Conferencia: <br>
      <input type="text" name="conferencia"><br>
      Division: <br>
      <input type="text" name="division"><br><br>

      <input type="submit" value="Añadir">
    </form>
  </body>
</html>
