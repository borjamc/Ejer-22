<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Resumen</title>
  </head>
  <body>
    <table>
      <tr>
        <td><a href="actores.php">Actores</a></td>
        <td><a href="actorestemp.php">Actores por temporada</a></td>
      </tr>
    </table>
    <table border="1">
    <?php

    include "gotdb.php";

    $thrones=new db();


    $resultado=$thrones->resumen();
    while ($fila=$resultado->fetch_assoc()) {
      echo "El titulo es: " . $fila["title"];
      echo "<br>";
      echo "Resumen: " . $fila["plot"];
    }



     ?>
   </table>
  </body>
</html>
