<!DOCTYPE html>
<html>
<head>
	<title>Resultados</title>
</head>
<body>
<?php 
$conexion = new mysqli("localhost", "root", "", "nba");
if ($conexion->connect_errno) {
    echo "Fallo al conectar a MySQL: (" . $conexion->connect_errno . ") " . $conexion->connect_error;
}else{
$select="SELECT equipo_local, equipo_visitante, puntos_local, puntos_visitante, temporada FROM partidos ORDER BY equipo_local=Bulls";
echo $select;
$resultado=$conexion->query($select);
echo "<table>";
echo "<tr>";
echo "<th>Equipo Local</th>";
echo "<th>Equipo Visitante</th>";
echo "<th>Puntos Local</th>";
echo "<th>Puntos Visitante</th>";
echo "<th>Temporada</th>";
echo "</tr>";
while ($filas=$resultado->fectch_assoc()) {
echo "<tr>";
echo "<td>" . $fila["equipo_local"] . "</td>";
echo "<td>" . $fila["equipo_visitante"] . "</td>";
echo "<td>" . $fila["puntos_visitante"] . "</td>";
echo "<td>" . $fila["puntos_local"] . "</td>";
echo "<td>" . $fila["temporada"] . "</td>";
echo "</tr>";
}
echo "</table>";
}
?>
</body>
</html>