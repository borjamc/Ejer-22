<!DOCTYPE html>
<html>
<head>
	<title>formulario</title>
</head>
<body>
<form class="" action="filtrado.php" method="post">
	Equipo local: <br>
	<input type="text" name="local"></input>
	<br>
	Equipo visitante:
	<br>
	<input type="text" name="visitante"></input>
	<br>
	Temporada:
	<br>
	<input type="text" name="temporada"></input>
	<br>
	<br>
	<input type="submit" name="boton"></input>
</form>
</body>
</html>
